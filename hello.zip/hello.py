def say_hello(name='Bob'):
    return name